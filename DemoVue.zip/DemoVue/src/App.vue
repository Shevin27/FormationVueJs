<template>
  <div>
    <h1>{{ message }}</h1>
     <!-- <PassInput
      v-model:id="filmToAdd.id"
      v-model:title="filmToAdd.title"
      v-model:genres="filmToAdd.genres"
      v-model:rating="filmToAdd.rating"
      v-model:description="filmToAdd.description"
    />  -->
     <label for="id">Movie id:</label><input id="id" v-model="filmToAdd.id" type="text" /> 
    <label for="title">Movie title:</label>
    <input id="title" v-model="filmToAdd.title" v-on:input="getData" type="text" />
    <label for="genres">Movie genres:</label>
    <input id="genres" v-model="filmToAdd.genres" type="text" /> 
    <label for="rating">Movie rating:</label>
    <v-rating
      v-model="filmToAdd.rating"
      length="10"
      bg-color="orange-lighten-1"
      color="blue"
      style="
    display: block;"
    ></v-rating>
    <label for="description">Movie description:</label>
    <input id="description" v-model="filmToAdd.description" type="text" /> 

    <button @click="addMovie">Add a Movie</button>
    <input type="text" placeholder="Filter by Title" v-model="filtrefilm" />
    <p v-if="films.length">Nous vous proposons ces {{ films.length }} films</p>
    <table class="styled-table">
      <thead>
        <tr>
          <th>Title</th>
          <th>Description</th>
          <th>Genres</th>
          <th>Rating</th>
        </tr>
      </thead>
      <singleFilm v-for="film in filtered_Movies" :key="film.id" :displayFilm="film"> </singleFilm>
    </table>
    <!-- <li v-for="(film, i) in filtered_Movies" :key="i">
        {{ film.title }}
        {{ film.description }}
        {{ film.genres }}
        {{ film.rating }}
      </li> -->
    <!-- <singleFilm v-for="film in filtered_Movies" :key="film.id" :title="film.title" :description="film.description" :genres="film.genres" :rating="film.rating"> -->
  </div>

  <ul>
    <li v-for="(film,i) in APImovies" :key="i">
      {{ film.title }} <a @click="GetMovie((film))" >Get the Movie</a>
    </li>
   </ul>

</template>
<script>
import { toHandlers } from 'vue'
import singleFilm from './components/singleFilm.vue'
import PassInput from './components/PassInput.vue'
import axios from 'axios'

export default {
  name: 'App',
  components: {
    singleFilm,
    PassInput
  },

  data() {
    return {
      message: 'Bienvenue sur VueFlix !',
      nombreFilms: '',
      APImovies: [],
      // On peut rajouter nos films ici
      films: [
        {
          id: 1,
          title: 'Parasites',
          genres: 'comedy',
          rating: 1,
          description:
            'Parasite (Korean: 기생충; RR: Gisaengchoong) is a 2019 South Korean black comedy.'
        },
        {
          id: 2,
          title: 'Harry Potter',
          genres: 'Thriller',
          rating: 3,
          description: 'A young boy who fears nothing (American: bla bla blaaaa.'
        },
        {
          id: 3,
          title: 'Lord of the rings',
          genres: 'Romance',
          rating: 5,
          description: 'Lord of the rings (American: bla bla blaaaa.'
        },
        {
          id: 4,
          title: 'Captain America',
          genres: 'Action',
          rating: 8,
          description: 'Captain America (French: bla bla blaaaa.'
        }
      ],

      filmToAdd: {
        id: 0,
        title: '',
        genres: '',
        rating: 0,
        description: ''
      },
      filtrefilm: ''
    }
  },
  computed: {
    filtered_Movies() {
      return this.films.filter((film) => film.title.startsWith(this.filtrefilm))
    }
  },

  methods: {
    addMovie() {
      // Add object item to array
      this.films.push(this.filmToAdd)
      this.filmToAdd = {}
    },
    getData() {
      axios
        .get(
          'https://api.themoviedb.org/3/search/movie?api_key=80d0dd074cbffeb2db4b0123882c7f44&query='+this.filmToAdd.title
        )
        .then((response) =>{
          console.log(response.data)
          this.APImovies = response.data.results
          console.log(this.APImovies)
        })
        .catch(function (error) {
          console.log(error)
        })
    },
    GetMovie(film){
      this.filmToAdd.id = film.id
      this.filmToAdd.title = film.title
      this.filmToAdd.description = film.overview
      this.filmToAdd.rating = film.vote_average
    }
  }
}
</script>

<style scoped>
header {
  line-height: 1.5;
}

.logo {
  display: block;
  margin: 0 auto 2rem;
}

@media (min-width: 1024px) {
  header {
    display: flex;
    place-items: center;
    padding-right: calc(var(--section-gap) / 2);
  }

  .logo {
    margin: 0 2rem 0 0;
  }

  header .wrapper {
    display: flex;
    place-items: flex-start;
    flex-wrap: wrap;
  }
}
input[type='text'],
select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

button {
  width: 100%;
  background-color: #009879;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type='submit']:hover {
  background-color: #45a049;
}

div {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}

.styled-table {
  border-collapse: collapse;
  margin: 25px 0;
  font-size: 0.9em;
  font-family: sans-serif;
  min-width: 400px;
  box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
}
.styled-table thead tr {
  background-color: #009879;
  color: #ffffff;
  text-align: left;
}
.styled-table th,
.styled-table td {
  padding: 12px 15px;
}
.styled-table tbody tr {
  border-bottom: 1px solid #dddddd;
}

.styled-table tbody tr:nth-of-type(even) {
  background-color: #f3f3f3;
}

.styled-table tbody tr:last-of-type {
  border-bottom: 2px solid #009879;
}
</style>
