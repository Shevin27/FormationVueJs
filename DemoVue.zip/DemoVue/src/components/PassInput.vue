<template>
  <div>
    <label for="id">Movie id:</label>
    <input type="text" :value="id" @input="$emit('update:id', $event.target.value)" />
    <label for="title">Movie title:</label>
    <input type="text" :value="title" @input="$emit('update:title', $event.target.value)" />
    <label for="genres">Movie genres:</label>
    <input type="text" :value="genres" @input="$emit('update:genres', $event.target.value)" />
    <label for="rating">Movie rating:</label><input type="text" :value="rating" @input="$emit('update:rating', $event.target.value)" />
    <label for="description">Movie description:</label><input type="text" :value="description" @input="$emit('update:description', $event.target.value)" />
  </div>
</template>

<script>
export default {
  props: {
    id: Int16Array,
    title: String,
    genres: String,
    rating: Int16Array,
    description: String
  }
}
</script>

<style scoped>
div {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
input[type='text'],
select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
</style>
