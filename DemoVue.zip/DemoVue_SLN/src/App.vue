<template>
  <div>
    <h1>{{ message }}</h1>
    <label for="id">Movie id:</label><input id="id" v-model="filmToAdd.id" type="text" />
    <label for="title">Movie title:</label
    ><input id="title" v-model="filmToAdd.title" type="text" />
    <label for="genres">Movie genres:</label
    ><input id="genres" v-model="filmToAdd.genres" type="text" />
    <label for="rating">Movie rating:</label
    ><input id="rating" v-model="filmToAdd.rating" type="text" />
    <label for="description">Movie description:</label
    ><input id="description" v-model="filmToAdd.description" type="text" />
    <button @click="addMovie">Add a Movie</button>
    <input type="text" placeholder="Filter by Title" v-model="filtrefilm" />
    <p v-if="films.length">Nous vous proposons ces {{ films.length }} films</p>
    <ul>
      <h2>Titre / Description / Genres / Rating</h2>
      <!-- <li v-for="(film, i) in filtered_Movies" :key="i">
        {{ film.title }}
        {{ film.description }}
        {{ film.genres }}
        {{ film.rating }}
      </li> -->
      <!-- <singleFilm v-for="film in filtered_Movies" :key="film.id" :title="film.title" :description="film.description" :genres="film.genres" :rating="film.rating"> -->
      <singleFilm v-for="film in filtered_Movies" :key="film.id" :displayFilm="film"> </singleFilm>
    </ul>
  </div>
</template>
<script>
import { toHandlers } from 'vue'
import singleFilm from './components/singleFilm.vue'
import PassInput from './components/PassInput.vue'

export default {
  name: 'App',
  components: {
    singleFilm,
    PassInput
  },

  data() {
    return {
      message: 'Bienvenue sur VueFlix !',
      nombreFilms: '',
      filters: {
        searchMovieTextValue: '',
        inputFilterText: ''
      },
      // On peut rajouter nos films ici
      films: [
        {
          id: 1,
          title: 'Parasite',
          genres: 'comedy',
          rating: 9,
          description:
            'Parasite (Korean: 기생충; RR: Gisaengchoong) is a 2019 South Korean black comedy thriller film directed by Bong Joon-ho, who also co-wrote the screenplay with Han Jin-won.'
        },
        {
          id: 2,
          title: 'Harry Potter',
          genres: 'Thriller',
          rating: 10,
          description: 'A young boy who fears nothing (American: bla bla blaaaa.'
        },
        {
          id: 3,
          title: 'Lord of the rings',
          genres: 'Romance',
          rating: 7,
          description: 'Lord of the rings (American: bla bla blaaaa.'
        },
        {
          id: 4,
          title: 'Captain America',
          genres: 'Action',
          rating: 6,
          description: 'Captain America (French: bla bla blaaaa.'
        }
      ],

      filmToAdd: {
        id: 0,
        title: '',
        genres: '',
        rating: 0,
        description: ''
      },
      filtrefilm: ''
    }
  },
  computed: {
    filtered_Movies() {
      return this.films.filter((film) => film.title.startsWith(this.filtrefilm))
    }
  },

  methods: {
    addMovie() {
      // Add object item to array
      this.films.push(this.filmToAdd)
      this.filmToAdd = {}
    }
  }
}
</script>

<style scoped>
header {
  line-height: 1.5;
}

.logo {
  display: block;
  margin: 0 auto 2rem;
}

@media (min-width: 1024px) {
  header {
    display: flex;
    place-items: center;
    padding-right: calc(var(--section-gap) / 2);
  }

  .logo {
    margin: 0 2rem 0 0;
  }

  header .wrapper {
    display: flex;
    place-items: flex-start;
    flex-wrap: wrap;
  }
}
input[type='text'],
select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

button {
  width: 100%;
  background-color: #4caf50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type='submit']:hover {
  background-color: #45a049;
}

div {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
</style>
