<template>
  <li>
    {{ displayFilm.title }} / {{ displayFilm.description }} / {{ displayFilm.genres }} /
    {{ displayFilm.rating }}
  </li>
</template>

<script>
export default {
  props: { displayFilm: Object }
  //   ['title','description','genres','rating']
}
</script>

<style scoped></style>
